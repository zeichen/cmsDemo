"use strict";
//var keyMirror= require('react/lib/keyMirror');

module.exports = {
    INITAILIZE: null,
    CREATE_AUTHOR: null


};